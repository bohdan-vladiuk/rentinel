import Layout from "../components/Layout";

export default function Home() {
  return (
    <Layout>
      <div className="container me-auto">
        <h1 className="row text-center">
          <p>This is Rentinel Project</p>
        </h1>
      </div>
    </Layout>
  );
}
